const express = require('express');
const fetch = require('node-fetch');

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/generate-payment-link', async (req, res) => {
    const { amount, cardholderName } = req.body;
    console.log("Received amount:", amount, "Received cardholderName:", cardholderName);
    // Endpoint URL, currently set to Staging environment, the one for production is https://eu-prod.oppwa.com/paybylink/v1
    try {
        const response = await fetch('https://eu-test.oppwa.com/paybylink/v1', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json',
                'Authorization': 'Bearer YOUR_ACCESS_TOKEN_HERE'
            },
            body: new URLSearchParams({
                'entityId': 'YOUR_ENTITY_ID_HERE',
                'amount': amount,
                'currency': 'EUR',
                'paymentType': 'DB',
                'merchantTransactionId': `ORDER-${Date.now()}`,
                'descriptor': 'Demo Payment',
                'customer.givenName': cardholderName,
                'customer.surname': 'TestSurname',
                'customer.email': 'demo@catalystpay.com',
                'shopperResultUrl': 'http://localhost:3000/payment-result',

                // Merchant branding
                'merchant.name': 'Your Merchant Name Ltd.; descriptor.com',
                'layout.logo': 'https://raw.githubusercontent.com/Catalystpay-LTD/catalyst-assets/main/logo3.png',
                'layout.logoWidth': '403px',
                'layout.logoHeight': '43px',
                'layout.backgroundImage': 'https://raw.githubusercontent.com/Catalystpay-LTD/catalyst-assets/main/newone5.png',
                'layout.merchantNameColor': '#0047bb',
                'layout.amountColor': '#66fecc',
                'layout.payButtonColor': '#191d5a',
                'layout.merchantNameColor': '#191d5a',
                'layout.payButtonTextColor': '#66fecc',
                
                // Legal links
                'termsAndConditionsUrl': 'https://catalystpay.com/legal/general/terms',
                'privacyPolicyUrl': 'https://catalystpay.com/legal/general/privacy'
            })
        });

        const rawText = await response.text();
        console.log("Raw response text:", rawText);

        let data;
        try {
            data = JSON.parse(rawText);
        } catch (parseError) {
            console.error("JSON Parse Error:", parseError);
            return res.status(400).json({
                error: 'Invalid JSON response from PayByLink API',
                raw: rawText,
                details: parseError.message
            });
        }

        if (data.link) {
            res.json({
                link: data.link,
                transactionId: data.id || 'N/A',
                shortId: data.shortId || 'Not provided'
            });
        } else {
            console.error("Error in PayByLink response:", data);
            res.status(400).json({ error: 'Failed to generate payment link', details: data });
        }
    } catch (error) {
        console.error('Error generating payment link:', error);
        res.status(500).json({ error: 'Failed to generate payment link' });
    }
});

app.get('/payment-result', (req, res) => {
    const { id, checkoutId } = req.query;

    const successMessage = (id && checkoutId)
        ? '✅ Your payment was successful!'
        : '⚠️ We could not verify your payment.';

    // Render simple clean page with no transaction/checkout ID displayed
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8" />
            <title>Payment Result</title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    text-align: center;
                    margin: 0;
                    padding: 50px 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-direction: column;
                }
                .container {
                    background: white;
                    padding: 40px;
                    border-radius: 12px;
                    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                    max-width: 500px;
                    width: 100%;
                }
                h1 {
                    color: #2d3748;
                    margin-bottom: 20px;
                    font-size: 2rem;
                }
                p {
                    color: #4a5568;
                    margin-bottom: 30px;
                    font-size: 1.1rem;
                }
                .button {
                    padding: 12px 24px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    border-radius: 8px;
                    text-decoration: none;
                    font-size: 16px;
                    cursor: pointer;
                    transition: transform 0.2s, box-shadow 0.2s;
                    display: inline-block;
                }
                .button:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>${successMessage}</h1>
                <p>Thank you for your payment.</p>
                <a href="/" class="button">⬅️ Back to Home</a>
            </div>
        </body>
        </html>
    `);
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
